class DirectionType extends NamedRange {
    static North = new DirectionType("NORTH");
    static West = new DirectionType("WEST");
    static South = new DirectionType("SOUTH");
    static East = new DirectionType("EAST");
}