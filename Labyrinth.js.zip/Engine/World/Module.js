class WorldModule extends Identifiable {
    constructor() {
        super();
    }
}