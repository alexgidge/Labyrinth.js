class WorldTile extends WorldModule {
    //TODO: Move tilemap into engine
    constructor() {
        super();
    }
}