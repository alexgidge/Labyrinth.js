class WorldTransform extends Identifiable {
    constructor(position) {
        super();
        this.Position = position;
    }
}