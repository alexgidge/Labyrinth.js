class GameWorld {
    //TODO: base for world & tile map?
}