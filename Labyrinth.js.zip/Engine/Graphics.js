class EngineGraphics {
    SetScreenText(text) {
        this.CurrentText = text;
        //TODO: Graphics UpdateText
    }
}
