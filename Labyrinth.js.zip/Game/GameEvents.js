class GameEvents {

    //TODO: Timed events with game turn
    //TODO: Timed events based on scenario triggers?
    //TODO: Timed events with game time?

}